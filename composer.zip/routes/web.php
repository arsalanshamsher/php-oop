<?php

use App\Services\Route;

Route::get('/', function () {
    return view('welcome');
});



