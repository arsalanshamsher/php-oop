<?php

namespace App\Controllers;

class Controller{
    
}